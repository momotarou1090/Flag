import consumer from "./consumer"

consumer.subscriptions.create("TweetsChannel", {
  connected() {
    console.log("Connected to the Tweets channel");
  },

  received(data) {
    const tweetsContainer = document.getElementById('tweets');
    tweetsContainer.innerHTML = data.html + tweetsContainer.innerHTML;
  }
});
